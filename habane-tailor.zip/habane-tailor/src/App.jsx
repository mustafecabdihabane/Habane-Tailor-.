import { useState, useRef } from "react";

const TODAY = new Date().toISOString().split("T")[0];
const fmt = (d) => d ? new Date(d).toLocaleDateString("en", { month: "short", day: "numeric" }) : "—";
const STYLES = ["Suit","Dirac","Baati","Blazer","Dress","Abaya","Kaftan","Custom"];

const GOLD = "#C9A84C";
const DARK = "#1A1208";
const CREAM = "#F9F5EE";
const BORDER = "#E8DFC8";

const STATUS_META = {
  Pending:       { bg:"#FFF7ED", text:"#C2410C", dot:"#FB923C", label:"La Sugayo" },
  "In Progress": { bg:"#EFF6FF", text:"#1D4ED8", dot:"#60A5FA", label:"Socda"    },
  Ready:         { bg:"#F0FDF4", text:"#15803D", dot:"#4ADE80", label:"Diyaar"   },
};

const BADGE_RULES = [
  { id:"platinum", emoji:"💎", label:"Macmiil Platinum", desc:"20+ dalabyo",  min:20, color:"#7C3AED", bg:"#F5F3FF" },
  { id:"gold",     emoji:"⭐", label:"Macmiil Dahab",    desc:"10+ dalabyo",  min:10, color:"#B45309", bg:"#FFFBEB" },
  { id:"silver",   emoji:"🥈", label:"Macmiil Lacag",   desc:"5+ dalabyo",   min:5,  color:"#374151", bg:"#F9FAFB" },
  { id:"bronze",   emoji:"🥉", label:"Macmiil Bir",     desc:"2+ dalabyo",   min:2,  color:"#92400E", bg:"#FEF3C7" },
  { id:"new",      emoji:"🌟", label:"Macmiil Cusub",   desc:"1aad dalabka", min:1,  color:"#0369A1", bg:"#EFF6FF" },
];
const getBadge = (n) => BADGE_RULES.find(b => n >= b.min) || null;

// ── VIP DESIGNS ─────────────────────────────────────────────────────────────
const VIP_DESIGNS = [
  { id:1, name:"Royal Dirac",    price:320, img:"https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=400&q=80", tag:"VIP", desc:"Xariir shidan, dahab" },
  { id:2, name:"Elite Suit",     price:480, img:"https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=400&q=80", tag:"VIP", desc:"Italiano fabric" },
  { id:3, name:"Luxury Abaya",   price:260, img:"https://images.unsplash.com/photo-1617627143233-c9d4fe5c8d6a?w=400&q=80", tag:"VIP", desc:"Dubai style" },
  { id:4, name:"Golden Kaftan",  price:380, img:"https://images.unsplash.com/photo-1585386959984-a4155224a1ad?w=400&q=80", tag:"VIP", desc:"Gees gees dahabeed" },
  { id:5, name:"Crystal Baati",  price:180, img:"https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=400&q=80", tag:"CUSUB", desc:"Xidid midab ah" },
  { id:6, name:"Premium Blazer", price:290, img:"https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=400&q=80", tag:"FADE", desc:"Casri ah" },
];

// ── PORTFOLIO ────────────────────────────────────────────────────────────────
const PORTFOLIO = [
  { id:1, title:"Dirac Dahabeed",  price:150, img:"https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=500&q=80", cat:"Dirac" },
  { id:2, title:"Suit Cas",        price:280, img:"https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=500&q=80", cat:"Suit"  },
  { id:3, title:"Abaya Buluug",    price:120, img:"https://images.unsplash.com/photo-1617627143233-c9d4fe5c8d6a?w=500&q=80", cat:"Abaya" },
  { id:4, title:"Kaftan Midab",    price:200, img:"https://images.unsplash.com/photo-1585386959984-a4155224a1ad?w=500&q=80", cat:"Kaftan"},
  { id:5, title:"Baati Cad",       price:80,  img:"https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=500&q=80", cat:"Baati" },
  { id:6, title:"Blazer Madow",    price:240, img:"https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=500&q=80", cat:"Suit"  },
  { id:7, title:"Dirac Casri",     price:175, img:"https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=500&q=80", cat:"Dirac" },
  { id:8, title:"Dress Geel-jire", price:135, img:"https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=500&q=80", cat:"Dress" },
];

const initOrders = [
  { id:1, name:"Amina Hassan", style:"Dirac",  notes:"Dahab, cabir M",   status:"Ready",       due:"2026-05-10", price:85,  paid:true,  photos:[], photosPublic:false, chat:[
    { from:"tailor", text:"Diraacdaadu way diyaartay!", time:"9:00 AM" },
    { from:"client", text:"Mahadsanid! Goorma ayaan iman karaa?", time:"9:15 AM" },
  ], phone:"252612000001"},
  { id:2, name:"Fadumo Ali",   style:"Abaya",  notes:"Buluug, dhirbaaxo", status:"In Progress", due:"2026-05-14", price:60,  paid:false, photos:[], photosPublic:false, chat:[
    { from:"tailor", text:"Waxay u baahan tahay 3 maalin kale.", time:"Maanta" },
  ], phone:"252612000002"},
  { id:3, name:"Amina Hassan", style:"Baati",  notes:"Casaan",            status:"Pending",     due:"2026-05-20", price:40,  paid:false, photos:[], photosPublic:false, chat:[], phone:"252612000001"},
];

const initClients = [
  { id:1, name:"Amina Hassan", phone:"252612000001", email:"", notes:"VIP macmiil", registered: "2026-01-10" },
  { id:2, name:"Fadumo Ali",   phone:"252612000002", email:"", notes:"",            registered: "2026-02-20" },
];

// ══════════════════════════════════════════════════════════════════════════════
export default function TailorApp() {
  const [orders,    setOrders]    = useState(initOrders);
  const [clients,   setClients]   = useState(initClients);
  const [view,      setView]      = useState("home");
  const [openId,    setOpenId]    = useState(null);
  const [chatMode,  setChatMode]  = useState("tailor");
  const [newMsg,    setNewMsg]    = useState("");
  const [search,    setSearch]    = useState("");
  const [filterS,   setFilterS]   = useState("All");
  const [showForm,  setShowForm]  = useState(false);
  const [nextId,    setNextId]    = useState(4);
  const [lightbox,  setLightbox]  = useState(null);
  const [payModal,  setPayModal]  = useState(null); // order id
  const [portCat,   setPortCat]   = useState("All");
  const [showRegForm, setShowRegForm] = useState(false);
  const [nextCid,   setNextCid]   = useState(3);
  const [form,      setForm]      = useState({ name:"", style:"", notes:"", due:"", price:"", phone:"" });
  const [regForm,   setRegForm]   = useState({ name:"", phone:"", email:"", notes:"" });
  const fileRef = useRef();

  // ── derived ─────────────────────────────────────────────────────────────────
  const clientMap = orders.reduce((acc, o) => {
    acc[o.name] = acc[o.name] || { name:o.name, orders:[] };
    acc[o.name].orders.push(o);
    return acc;
  }, {});

  const filtered = orders.filter(o => {
    const ms = (o.name+o.style).toLowerCase().includes(search.toLowerCase());
    const mf = filterS==="All" || o.status===filterS;
    return ms && mf;
  });

  const totalRev  = orders.filter(o=>o.paid).reduce((s,o)=>s+o.price,0);
  const totalOwed = orders.filter(o=>!o.paid).reduce((s,o)=>s+o.price,0);
  const openOrder = orders.find(o=>o.id===openId);

  // ── actions ──────────────────────────────────────────────────────────────────
  const addOrder = () => {
    if (!form.name.trim() || !form.style) return;
    setOrders([{ id:nextId, ...form, price:Number(form.price)||0, paid:false, status:"Pending", photos:[], photosPublic:false, chat:[] }, ...orders]);
    setNextId(nextId+1);
    setForm({ name:"", style:"", notes:"", due:"", price:"", phone:"" });
    setShowForm(false);
  };
  const cycleStatus = (id) => {
    const c=["Pending","In Progress","Ready"];
    setOrders(orders.map(o=>o.id===id?{...o,status:c[(c.indexOf(o.status)+1)%3]}:o));
  };
  const togglePaid = (id) => setOrders(orders.map(o=>o.id===id?{...o,paid:!o.paid}:o));
  const deleteOrder = (id) => { setOrders(orders.filter(o=>o.id!==id)); if(openId===id)setOpenId(null); };

  const sendWhatsApp = (order) => {
    const msg = `Assalamu Calaykum ${order.name}! 🌙\n\nDalabkaaga *Habane Tailor* waa diyaar!\n\n✂ Nooca: *${order.style}*${order.notes?`\n📝 ${order.notes}`:""}${order.due?`\n📅 ${fmt(order.due)}`:""}\n📦 Xaaladda: *${STATUS_META[order.status].label}*\n\nMahadsanid! 🙏 *Habane Tailor*`;
    const phone=(order.phone||"").replace(/\D/g,"");
    window.open(phone?`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`:`https://wa.me/?text=${encodeURIComponent(msg)}`,"_blank");
  };

  const sendMsg = (isPrivate=false) => {
    if (!newMsg.trim()||!openId) return;
    const now=new Date().toLocaleTimeString("en",{hour:"2-digit",minute:"2-digit"});
    const from=isPrivate?"tailor_private":chatMode;
    setOrders(orders.map(o=>o.id===openId?{...o,chat:[...o.chat,{from,text:newMsg.trim(),time:now}]}:o));
    setNewMsg("");
  };

  const addRegClient = () => {
    if (!regForm.name.trim()) return;
    setClients([...clients, { id:nextCid, ...regForm, registered:TODAY }]);
    setNextCid(nextCid+1);
    setRegForm({ name:"", phone:"", email:"", notes:"" });
    setShowRegForm(false);
  };

  // ── shared styles ─────────────────────────────────────────────────────────
  const inp = { width:"100%", padding:"10px 13px", border:`1px solid ${BORDER}`, background:CREAM, fontSize:"13px", fontFamily:"'Georgia',serif", color:DARK, outline:"none", boxSizing:"border-box" };
  const btnGold = { background:`linear-gradient(135deg,${GOLD},#E8C96A)`, color:DARK, border:"none", padding:"10px 20px", cursor:"pointer", fontSize:"12px", fontFamily:"sans-serif", fontWeight:"800", letterSpacing:"1px" };
  const btnDark = { background:DARK, color:CREAM, border:"none", padding:"10px 18px", cursor:"pointer", fontSize:"12px", fontFamily:"sans-serif", fontWeight:"600", letterSpacing:"1px" };

  // ── NAV items ─────────────────────────────────────────────────────────────
  const NAV = [
    ["home",      "🏠", "Hoyga"],
    ["orders",    "📋", "Dalabyo"],
    ["clients",   "👤", "Macaamiil"],
    ["portfolio", "🖼", "Nashqado"],
    ["vip",       "💎", "VIP"],
    ["training",  "🎓", "Barashada"],
    ["stats",     "📊", "Xisaab"],
  ];

  // ══════════════════════════════════════════════════════════════════════════
  return (
    <div style={{ minHeight:"100vh", background:CREAM, fontFamily:"'Georgia',serif", display:"flex", flexDirection:"column" }}>

      {/* ── HEADER ── */}
      <header style={{ background:DARK, borderBottom:`2px solid ${GOLD}` }}>
        <div style={{ maxWidth:"820px", margin:"0 auto", padding:"0 16px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div style={{ padding:"14px 0" }}>
            <div style={{ color:GOLD, fontSize:"9px", letterSpacing:"4px", fontFamily:"sans-serif" }}>EST. 2024 · BOORAMA</div>
            <div style={{ color:"#F9F5EE", fontSize:"22px", letterSpacing:"2px", marginTop:"2px" }}>✂ HABANE TAILOR</div>
          </div>
          <div style={{ color:GOLD, fontSize:"11px", fontFamily:"sans-serif", textAlign:"right" }}>
            <div>📋 {orders.length} Dalabyo</div>
            <div>💰 ${totalRev} La helay</div>
          </div>
        </div>
        {/* nav */}
        <div style={{ background:"rgba(201,168,76,0.1)", borderTop:`1px solid rgba(201,168,76,0.2)`, overflowX:"auto" }}>
          <div style={{ display:"flex", maxWidth:"820px", margin:"0 auto", padding:"0 8px" }}>
            {NAV.map(([v,e,l])=>(
              <button key={v} onClick={()=>{setView(v);setOpenId(null);}} style={{
                background:"none", border:"none", padding:"10px 12px", cursor:"pointer",
                color:view===v?GOLD:"#9CA3AF", fontFamily:"sans-serif", fontSize:"11px",
                fontWeight:view===v?"800":"400", borderBottom:view===v?`2px solid ${GOLD}`:"2px solid transparent",
                whiteSpace:"nowrap",
              }}>{e} {l}</button>
            ))}
          </div>
        </div>
      </header>

      <div style={{ flex:1, maxWidth:"820px", margin:"0 auto", width:"100%", padding:"18px 14px" }}>

        {/* ══ HOME ══ */}
        {view==="home" && (
          <div>
            {/* Hero */}
            <div style={{ background:`linear-gradient(135deg,${DARK} 60%,#3D2B00)`, padding:"32px 28px", marginBottom:"20px", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:-20, right:-20, width:"120px", height:"120px", borderRadius:"50%", background:"rgba(201,168,76,0.08)" }}/>
              <div style={{ color:GOLD, fontSize:"10px", letterSpacing:"4px", fontFamily:"sans-serif", marginBottom:"8px" }}>HABANE TAILOR · BOORAMA</div>
              <div style={{ color:"#F9F5EE", fontSize:"28px", fontWeight:"400", lineHeight:"1.3", marginBottom:"12px" }}>
                Nashqad kasta<br/><span style={{ color:GOLD }}>Farshaxan gaar ah</span>
              </div>
              <div style={{ color:"#9CA3AF", fontSize:"13px", fontFamily:"sans-serif", marginBottom:"20px" }}>Tarzanka ugu heerka sareeyaa Muqdisho</div>
              <div style={{ display:"flex", gap:"10px", flexWrap:"wrap" }}>
                <button onClick={()=>setView("orders")} style={btnGold}>📋 Dalabyo arag</button>
                <button onClick={()=>setView("portfolio")} style={{ ...btnDark, border:`1px solid ${GOLD}`, color:GOLD }}>🖼 Nashqado eeg</button>
              </div>
            </div>

            {/* Stats strip */}
            <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:"8px", marginBottom:"20px" }}>
              {[
                ["📋", orders.length, "Dalabyo"],
                ["👤", Object.keys(clientMap).length, "Macaamiil"],
                ["💰", `$${totalRev}`, "La helay"],
                ["⏳", `$${totalOwed}`, "Sugaya"],
              ].map(([e,v,l])=>(
                <div key={l} style={{ background:"#fff", border:`1px solid ${BORDER}`, padding:"14px 10px", textAlign:"center" }}>
                  <div style={{ fontSize:"18px", marginBottom:"4px" }}>{e}</div>
                  <div style={{ fontSize:"18px", color:DARK, fontWeight:"400" }}>{v}</div>
                  <div style={{ fontSize:"10px", color:"#9CA3AF", fontFamily:"sans-serif" }}>{l}</div>
                </div>
              ))}
            </div>

            {/* Recent orders */}
            <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD, marginBottom:"12px" }}>DALABYADII DAMBE</div>
            {orders.slice(0,3).map(o=>{
              const sm=STATUS_META[o.status];
              return (
                <div key={o.id} onClick={()=>{setView("orders");setOpenId(o.id);}} style={{ background:"#fff", border:`1px solid ${BORDER}`, padding:"12px 16px", marginBottom:"8px", cursor:"pointer", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div>
                    <div style={{ fontSize:"14px", color:DARK, fontWeight:"600" }}>{o.name}</div>
                    <div style={{ fontSize:"12px", color:"#78716C", fontFamily:"sans-serif" }}>{o.style} · {fmt(o.due)}</div>
                  </div>
                  <span style={{ background:sm.bg, color:sm.text, fontSize:"10px", fontFamily:"sans-serif", fontWeight:"700", padding:"3px 10px" }}>{sm.label}</span>
                </div>
              );
            })}

            {/* VIP preview */}
            <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD, margin:"20px 0 12px" }}>💎 NASHQADAHA VIP</div>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"8px" }}>
              {VIP_DESIGNS.slice(0,3).map(d=>(
                <div key={d.id} onClick={()=>setView("vip")} style={{ cursor:"pointer", background:"#fff", border:`1px solid ${BORDER}`, overflow:"hidden" }}>
                  <img src={d.img} alt={d.name} style={{ width:"100%", height:"90px", objectFit:"cover", display:"block" }}/>
                  <div style={{ padding:"8px" }}>
                    <div style={{ fontSize:"11px", fontWeight:"600", color:DARK }}>{d.name}</div>
                    <div style={{ fontSize:"11px", color:GOLD, fontFamily:"sans-serif", fontWeight:"700" }}>${d.price}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ ORDERS LIST ══ */}
        {view==="orders" && !openId && (<>
          <div style={{ display:"flex", gap:"8px", marginBottom:"12px" }}>
            <input placeholder="🔍 Raadi..." value={search} onChange={e=>setSearch(e.target.value)} style={{ ...inp, flex:1 }}/>
            <button onClick={()=>setShowForm(!showForm)} style={btnGold}>{showForm?"✕":"+ Dalabka"}</button>
          </div>

          {showForm && (
            <div style={{ background:"#fff", border:`1px solid ${BORDER}`, padding:"18px", marginBottom:"14px", boxShadow:"0 4px 20px rgba(0,0,0,0.06)" }}>
              <div style={{ fontSize:"10px", fontFamily:"sans-serif", letterSpacing:"3px", color:GOLD, marginBottom:"12px" }}>DALABKA CUSUB</div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"9px" }}>
                <input placeholder="Magaca macmiilka" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} style={{ ...inp, gridColumn:"1/-1" }}/>
                <select value={form.style} onChange={e=>setForm({...form,style:e.target.value})} style={{ ...inp, color:form.style?DARK:"#9CA3AF" }}>
                  <option value="" disabled>Nooca dharka</option>
                  {STYLES.map(s=><option key={s}>{s}</option>)}
                </select>
                <input type="number" placeholder="Qiimaha ($)" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} style={inp}/>
                <input type="date" value={form.due} onChange={e=>setForm({...form,due:e.target.value})} style={{ ...inp, gridColumn:"1/-1" }}/>
                <input placeholder="📱 WhatsApp (252...)" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} style={{ ...inp, gridColumn:"1/-1" }}/>
                <textarea placeholder="Xusuus-qor..." value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} rows={2} style={{ ...inp, gridColumn:"1/-1", resize:"none" }}/>
              </div>
              <button onClick={addOrder} disabled={!form.name.trim()||!form.style} style={{ ...btnGold, marginTop:"10px", width:"100%", opacity:form.name.trim()&&form.style?1:0.4 }}>
                Kudar Dalabka
              </button>
            </div>
          )}

          <div style={{ display:"flex", gap:"3px", background:"#EDE9E3", padding:"3px", marginBottom:"12px" }}>
            {["All","Pending","In Progress","Ready"].map(f=>(
              <button key={f} onClick={()=>setFilterS(f)} style={{
                flex:1, padding:"7px 3px", border:"none",
                background:filterS===f?DARK:"transparent",
                color:filterS===f?GOLD:"#78716C",
                cursor:"pointer", fontSize:"11px", fontFamily:"sans-serif", fontWeight:"700",
              }}>
                {f==="All"?"Dhammaan":STATUS_META[f]?.label}
                <span style={{ opacity:.5 }}> ({f==="All"?orders.length:orders.filter(o=>o.status===f).length})</span>
              </button>
            ))}
          </div>

          {filtered.length===0
            ? <div style={{ textAlign:"center", padding:"40px", color:GOLD, fontFamily:"sans-serif" }}>✂ Wax lama helin</div>
            : filtered.map(order=>{
              const sm=STATUS_META[order.status];
              const isOverdue=order.due&&order.due<TODAY&&order.status!=="Ready";
              return (
                <div key={order.id} onClick={()=>setOpenId(order.id)} style={{ background:"#fff", border:`1px solid ${BORDER}`, marginBottom:"8px", cursor:"pointer", borderLeft:isOverdue?"4px solid #EF4444":`4px solid ${GOLD}`, overflow:"hidden" }}>
                  {order.photosPublic&&order.photos.length>0&&(
                    <div style={{ display:"flex", gap:"2px", height:"85px", overflow:"hidden", background:DARK }}>
                      {order.photos.slice(0,4).map((p,i)=>(
                        <div key={i} style={{ flex:1, minWidth:0, position:"relative" }}>
                          <img src={p} alt="" style={{ width:"100%", height:"100%", objectFit:"cover", display:"block", opacity:.9 }}/>
                          {i===3&&order.photos.length>4&&<div style={{ position:"absolute", inset:0, background:"rgba(0,0,0,0.55)", display:"flex", alignItems:"center", justifyContent:"center", color:"#fff", fontSize:"14px", fontFamily:"sans-serif", fontWeight:"700" }}>+{order.photos.length-4}</div>}
                        </div>
                      ))}
                    </div>
                  )}
                  <div style={{ padding:"12px 16px", display:"flex", gap:"12px", alignItems:"center" }}>
                    <div style={{ width:"32px", height:"32px", background:"#F5F0E8", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"10px", color:GOLD, fontFamily:"sans-serif", fontWeight:"700", flexShrink:0 }}>
                      #{String(order.id).padStart(2,"0")}
                    </div>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:"6px", marginBottom:"2px" }}>
                        <span style={{ fontWeight:"600", color:DARK, fontSize:"14px" }}>{order.name}</span>
                        {getBadge(clientMap[order.name]?.orders.length||0)&&<span style={{ fontSize:"13px" }}>{getBadge(clientMap[order.name].orders.length).emoji}</span>}
                      </div>
                      <div style={{ fontSize:"12px", color:"#78716C", fontFamily:"sans-serif" }}>{order.style}{order.notes&&<span style={{ color:"#B0A898" }}> · {order.notes}</span>}</div>
                      {order.due&&<div style={{ fontSize:"11px", color:isOverdue?"#EF4444":"#9CA3AF", fontFamily:"sans-serif", marginTop:"2px" }}>{isOverdue?"⚠ Waqti dhaafay":"📅"} {fmt(order.due)}</div>}
                    </div>
                    <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:"5px" }}>
                      <span style={{ background:sm.bg, color:sm.text, fontSize:"10px", fontFamily:"sans-serif", fontWeight:"700", padding:"3px 9px", display:"flex", alignItems:"center", gap:"4px" }}>
                        <span style={{ width:"5px", height:"5px", borderRadius:"50%", background:sm.dot, display:"inline-block" }}/>{sm.label}
                      </span>
                      <span style={{ fontSize:"12px", color:order.paid?"#15803D":"#C2410C", fontFamily:"sans-serif", fontWeight:"600" }}>${order.price} {order.paid?"✓":"⏳"}</span>
                      <button onClick={e=>{e.stopPropagation();setPayModal(order.id);}} style={{ background:order.paid?"#F0FDF4":GOLD, color:order.paid?"#15803D":DARK, border:"none", padding:"3px 9px", cursor:"pointer", fontSize:"10px", fontFamily:"sans-serif", fontWeight:"800" }}>
                        {order.paid?"✓ Bixiyay":"💳 Bixi"}
                      </button>
                      <button onClick={e=>{e.stopPropagation();sendWhatsApp(order);}} style={{ background:"#25D366", color:"#fff", border:"none", padding:"3px 9px", cursor:"pointer", fontSize:"10px", fontFamily:"sans-serif", fontWeight:"700" }}>📲 WA</button>
                    </div>
                  </div>
                </div>
              );
            })
          }
        </>)}

        {/* ══ ORDER DETAIL ══ */}
        {view==="orders" && openId && openOrder && (
          <div>
            <button onClick={()=>setOpenId(null)} style={{ background:"none", border:"none", color:GOLD, cursor:"pointer", fontFamily:"sans-serif", fontSize:"13px", marginBottom:"10px", padding:0 }}>← Dib u noqo</button>
            <div style={{ background:DARK, padding:"18px", marginBottom:"10px", borderBottom:`2px solid ${GOLD}` }}>
              <div style={{ color:GOLD, fontSize:"10px", fontFamily:"sans-serif", letterSpacing:"2px" }}>DALABKA #{String(openOrder.id).padStart(2,"0")}</div>
              <div style={{ color:"#F9F5EE", fontSize:"20px", marginTop:"3px" }}>{openOrder.name}</div>
              <div style={{ color:"#9CA3AF", fontSize:"12px", fontFamily:"sans-serif", marginTop:"3px" }}>{openOrder.style} {openOrder.notes&&`· ${openOrder.notes}`} {openOrder.due&&`· 📅 ${fmt(openOrder.due)}`}</div>
              <div style={{ display:"flex", gap:"8px", marginTop:"12px", flexWrap:"wrap" }}>
                <button onClick={()=>cycleStatus(openOrder.id)} style={{ background:STATUS_META[openOrder.status].bg, color:STATUS_META[openOrder.status].text, border:"none", padding:"6px 14px", cursor:"pointer", fontSize:"11px", fontFamily:"sans-serif", fontWeight:"700" }}>⟳ {STATUS_META[openOrder.status].label}</button>
                <button onClick={()=>setPayModal(openOrder.id)} style={{ background:openOrder.paid?"#F0FDF4":GOLD, color:openOrder.paid?"#15803D":DARK, border:`2px solid ${openOrder.paid?"#4ADE80":GOLD}`, padding:"6px 14px", cursor:"pointer", fontSize:"11px", fontFamily:"sans-serif", fontWeight:"800" }}>
                  💰 ${openOrder.price} — {openOrder.paid?`✓ ${openOrder.payMethod||"La bixiyay"}`:"💳 Lacag Bixi"}
                </button>
                <button onClick={()=>sendWhatsApp(openOrder)} style={{ background:"#25D366", color:"#fff", border:"none", padding:"6px 14px", cursor:"pointer", fontSize:"11px", fontFamily:"sans-serif", fontWeight:"700" }}>📲 WhatsApp</button>
                <button onClick={()=>deleteOrder(openOrder.id)} style={{ background:"#3D1A1A", color:"#EF4444", border:"none", padding:"6px 12px", cursor:"pointer", fontSize:"11px", fontFamily:"sans-serif" }}>🗑 Tirtir</button>
              </div>
            </div>

            {/* Photos */}
            <div style={{ background:"#fff", border:`1px solid ${BORDER}`, padding:"14px", marginBottom:"10px" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"10px" }}>
                <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD }}>SAWIRRADA DHARKA</div>
                <div style={{ display:"flex", gap:"6px", alignItems:"center" }}>
                  <span style={{ fontSize:"10px", fontFamily:"sans-serif", color:"#9CA3AF" }}>Macmiilku arko:</span>
                  <button onClick={()=>setOrders(orders.map(o=>o.id===openId?{...o,photosPublic:!o.photosPublic}:o))}
                    style={{ background:openOrder.photosPublic?"#F0FDF4":"#F5F0E8", color:openOrder.photosPublic?"#15803D":"#78716C", border:"none", padding:"4px 10px", cursor:"pointer", fontSize:"11px", fontFamily:"sans-serif", fontWeight:"700" }}>
                    {openOrder.photosPublic?"✅ Haa":"🔒 Maya"}
                  </button>
                </div>
              </div>
              {openOrder.photos.length===0
                ? <div style={{ textAlign:"center", padding:"18px", color:"#B0A898", fontSize:"12px", fontFamily:"sans-serif", border:"2px dashed #E5E0D8" }}>📷 Sawir ma jirto — ku dar</div>
                : <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(78px,1fr))", gap:"7px", marginBottom:"10px" }}>
                    {openOrder.photos.map((p,i)=>(
                      <div key={i} style={{ position:"relative", aspectRatio:"1", cursor:"pointer" }} onClick={()=>setLightbox(p)}>
                        <img src={p} alt="" style={{ width:"100%", height:"100%", objectFit:"cover", border:`1px solid ${BORDER}`, display:"block" }}/>
                        <button onClick={e=>{e.stopPropagation();setOrders(orders.map(o=>o.id===openId?{...o,photos:o.photos.filter((_,j)=>j!==i)}:o));}}
                          style={{ position:"absolute", top:"3px", right:"3px", background:"rgba(0,0,0,0.65)", color:"#fff", border:"none", width:"18px", height:"18px", cursor:"pointer", fontSize:"12px", display:"flex", alignItems:"center", justifyContent:"center" }}>×</button>
                      </div>
                    ))}
                  </div>
              }
              <button onClick={()=>fileRef.current.click()} style={{ width:"100%", padding:"10px", border:`2px dashed ${BORDER}`, background:CREAM, cursor:"pointer", color:GOLD, fontSize:"13px", fontFamily:"sans-serif", boxSizing:"border-box" }}>📷 Sawir ku dar</button>
              <input ref={fileRef} type="file" accept="image/*" multiple style={{ display:"none" }} onChange={e=>{
                Array.from(e.target.files).forEach(file=>{ const url=URL.createObjectURL(file); setOrders(prev=>prev.map(o=>o.id===openId?{...o,photos:[...o.photos,url]}:o)); });
              }}/>
            </div>

            {/* Chat */}
            <div style={{ background:"#fff", border:`1px solid ${BORDER}`, padding:"14px" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"10px" }}>
                <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD }}>XIRIIRKA</div>
                <div style={{ display:"flex", background:"#F5F0E8", overflow:"hidden" }}>
                  {[["tailor","🧵 Tarzanka"],["client","👤 Macmiilka"]].map(([r,l])=>(
                    <button key={r} onClick={()=>setChatMode(r)} style={{ padding:"5px 10px", border:"none", cursor:"pointer", fontSize:"11px", fontFamily:"sans-serif", fontWeight:"600", background:chatMode===r?DARK:"transparent", color:chatMode===r?GOLD:"#78716C" }}>{l}</button>
                  ))}
                </div>
              </div>
              {chatMode==="client"&&openOrder.photosPublic&&openOrder.photos.length>0&&(
                <div style={{ marginBottom:"10px", padding:"10px", background:CREAM, border:`1px solid ${BORDER}` }}>
                  <div style={{ fontSize:"10px", fontFamily:"sans-serif", color:GOLD, letterSpacing:"1px", marginBottom:"7px" }}>📸 SAWIRRADA DHARKAAAGA</div>
                  <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(68px,1fr))", gap:"5px" }}>
                    {openOrder.photos.map((p,i)=><img key={i} src={p} alt="" onClick={()=>setLightbox(p)} style={{ width:"100%", aspectRatio:"1", objectFit:"cover", border:`1px solid ${BORDER}`, cursor:"pointer", display:"block" }}/>)}
                  </div>
                </div>
              )}
              <div style={{ maxHeight:"190px", overflowY:"auto", display:"flex", flexDirection:"column", gap:"7px", marginBottom:"10px" }}>
                {openOrder.chat.length===0
                  ? <div style={{ textAlign:"center", color:"#B0A898", fontSize:"12px", padding:"16px", fontFamily:"sans-serif" }}>Wali fariin ma jirto</div>
                  : openOrder.chat.map((m,i)=>{
                    if (chatMode==="client"&&m.from==="tailor_private") return null;
                    const isMine=m.from===chatMode||(chatMode==="tailor"&&m.from==="tailor_private");
                    return (
                      <div key={i} style={{ display:"flex", justifyContent:isMine?"flex-end":"flex-start" }}>
                        <div style={{ maxWidth:"78%", padding:"8px 12px", background:isMine?DARK:m.from==="tailor_private"?"#FFF7ED":"#F5F0E8", color:isMine?"#F9F5EE":m.from==="tailor_private"?"#C2410C":DARK, fontSize:"13px", fontFamily:"sans-serif", lineHeight:"1.4", borderRadius:isMine?"8px 8px 0 8px":"8px 8px 8px 0", border:m.from==="tailor_private"?"1px dashed #FCA5A5":"none" }}>
                          {m.from==="tailor_private"&&<div style={{ fontSize:"10px", marginBottom:"2px", opacity:.7 }}>🔒 Qaarsoon</div>}
                          {m.text}
                          <div style={{ fontSize:"10px", opacity:.4, marginTop:"2px", textAlign:"right" }}>{m.time}</div>
                        </div>
                      </div>
                    );
                  })
                }
              </div>
              <div style={{ display:"flex", gap:"6px" }}>
                <input value={newMsg} onChange={e=>setNewMsg(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendMsg(false)} placeholder={chatMode==="tailor"?"Fariinta tarzanka...":"Fariinta macmiilka..."} style={{ ...inp, flex:1 }}/>
                {chatMode==="tailor"&&<button onClick={()=>sendMsg(true)} title="Qaarsoon" style={{ background:"#FFF7ED", border:"1px solid #FCA5A5", padding:"0 10px", cursor:"pointer", color:"#C2410C", fontSize:"14px" }}>🔒</button>}
                <button onClick={()=>sendMsg(false)} style={{ ...btnDark, padding:"0 14px" }}>↑</button>
              </div>
            </div>
          </div>
        )}

        {/* ══ CLIENTS ══ */}
        {view==="clients" && (
          <div>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"14px" }}>
              <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD }}>MACAAMIISHA ({clients.length})</div>
              <button onClick={()=>setShowRegForm(!showRegForm)} style={btnGold}>{showRegForm?"✕ Jooji":"+ Diiwaangeli"}</button>
            </div>

            {showRegForm&&(
              <div style={{ background:"#fff", border:`1px solid ${BORDER}`, padding:"18px", marginBottom:"14px", boxShadow:"0 4px 16px rgba(0,0,0,0.06)" }}>
                <div style={{ fontSize:"10px", fontFamily:"sans-serif", letterSpacing:"3px", color:GOLD, marginBottom:"12px" }}>DIIWAANGELINTA MACMIILKA CUSUB</div>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"9px" }}>
                  <input placeholder="Magaca buuxa *" value={regForm.name} onChange={e=>setRegForm({...regForm,name:e.target.value})} style={{ ...inp, gridColumn:"1/-1" }}/>
                  <input placeholder="📱 Telefoonka" value={regForm.phone} onChange={e=>setRegForm({...regForm,phone:e.target.value})} style={inp}/>
                  <input placeholder="📧 Email (ikhtiyaari)" value={regForm.email} onChange={e=>setRegForm({...regForm,email:e.target.value})} style={inp}/>
                  <textarea placeholder="Xusuus-qor..." value={regForm.notes} onChange={e=>setRegForm({...regForm,notes:e.target.value})} rows={2} style={{ ...inp, gridColumn:"1/-1", resize:"none" }}/>
                </div>
                <button onClick={addRegClient} disabled={!regForm.name.trim()} style={{ ...btnGold, marginTop:"10px", width:"100%", opacity:regForm.name.trim()?1:0.4 }}>
                  Diiwaangeli Macmiilka
                </button>
              </div>
            )}

            {clients.map((c,idx)=>{
              const orderCount=clientMap[c.name]?.orders.length||0;
              const badge=getBadge(orderCount);
              const spent=(clientMap[c.name]?.orders||[]).reduce((s,o)=>s+(o.paid?o.price:0),0);
              const owed=(clientMap[c.name]?.orders||[]).reduce((s,o)=>s+(!o.paid?o.price:0),0);
              // abaal marin: 1st client gets special treatment
              const isTop = idx===0;
              return (
                <div key={c.id} style={{ background:"#fff", border:`1px solid ${BORDER}`, padding:"16px", marginBottom:"10px", boxShadow: isTop?`0 0 0 2px ${GOLD}`:"none", position:"relative", overflow:"hidden" }}>
                  {isTop&&<div style={{ position:"absolute", top:0, right:0, background:`linear-gradient(135deg,${GOLD},#E8C96A)`, color:DARK, fontSize:"9px", fontFamily:"sans-serif", fontWeight:"800", padding:"4px 12px", letterSpacing:"2px" }}>🏆 #1 MACMIILKA</div>}
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"10px" }}>
                    <div>
                      <div style={{ fontSize:"16px", color:DARK, marginBottom:"5px" }}>{c.name}</div>
                      {badge&&<span style={{ fontSize:"12px", fontFamily:"sans-serif", background:badge.bg, color:badge.color, padding:"2px 10px" }}>{badge.emoji} {badge.label}</span>}
                      <div style={{ fontSize:"11px", color:"#9CA3AF", fontFamily:"sans-serif", marginTop:"5px" }}>📅 Diiwaan: {fmt(c.registered)} · 📱 {c.phone||"—"}</div>
                    </div>
                    <div style={{ textAlign:"right", fontFamily:"sans-serif", fontSize:"12px" }}>
                      <div style={{ color:"#15803D", fontWeight:"700" }}>${spent} la bixiyay</div>
                      {owed>0&&<div style={{ color:"#C2410C" }}>${owed} wali ah</div>}
                      <div style={{ color:"#9CA3AF", marginTop:"3px" }}>{orderCount} dalabyo</div>
                    </div>
                  </div>
                  {/* badge progress */}
                  {badge&&(
                    <div style={{ marginBottom:"10px" }}>
                      <div style={{ fontSize:"10px", fontFamily:"sans-serif", color:"#9CA3AF", marginBottom:"4px" }}>
                        {badge.id==="platinum"?"💎 Ugu sarreeya!":
                         badge.id==="gold"?`${20-orderCount} oo kale → 💎 Platinum`:
                         badge.id==="silver"?`${10-orderCount} oo kale → ⭐ Dahab`:
                         badge.id==="bronze"?`${5-orderCount} oo kale → 🥈 Lacag`:
                         `${2-orderCount} oo kale → 🥉 Bir`}
                      </div>
                      <div style={{ background:"#F5F0E8", height:"5px", borderRadius:"3px", overflow:"hidden" }}>
                        <div style={{ height:"100%", background:`linear-gradient(90deg,${GOLD},#E8C96A)`, width:`${Math.min(100,(orderCount/20)*100)}%`, transition:"width 0.5s" }}/>
                      </div>
                    </div>
                  )}
                  <div style={{ display:"flex", gap:"6px", flexWrap:"wrap" }}>
                    {(clientMap[c.name]?.orders||[]).map(o=>{
                      const sm=STATUS_META[o.status];
                      return <div key={o.id} onClick={()=>{setView("orders");setOpenId(o.id);}} style={{ background:sm.bg, color:sm.text, fontSize:"11px", fontFamily:"sans-serif", padding:"4px 10px", cursor:"pointer", border:`1px solid ${sm.dot}` }}>{o.style} · {sm.label}</div>;
                    })}
                  </div>
                  {c.phone&&<button onClick={()=>sendWhatsApp({name:c.name,style:"",notes:"",status:"Pending",phone:c.phone,price:0,due:""})} style={{ ...btnDark, background:"#25D366", marginTop:"10px", padding:"6px 14px", fontSize:"11px" }}>📲 WhatsApp u dir</button>}
                </div>
              );
            })}
          </div>
        )}

        {/* ══ PORTFOLIO — NASHQADAHA ══ */}
        {view==="portfolio" && (
          <div>
            <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD, marginBottom:"14px" }}>🖼 NASHQADAHA AN TOLO</div>
            <div style={{ display:"flex", gap:"6px", flexWrap:"wrap", marginBottom:"14px" }}>
              {["All",...new Set(PORTFOLIO.map(p=>p.cat))].map(c=>(
                <button key={c} onClick={()=>setPortCat(c)} style={{ background:portCat===c?DARK:CREAM, color:portCat===c?GOLD:DARK, border:`1px solid ${BORDER}`, padding:"5px 14px", cursor:"pointer", fontSize:"11px", fontFamily:"sans-serif", fontWeight:"700" }}>
                  {c==="All"?"Dhammaan":c}
                </button>
              ))}
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:"10px" }}>
              {PORTFOLIO.filter(p=>portCat==="All"||p.cat===portCat).map(p=>(
                <div key={p.id} onClick={()=>setLightbox(p.img)} style={{ background:"#fff", border:`1px solid ${BORDER}`, overflow:"hidden", cursor:"pointer" }}>
                  <div style={{ position:"relative" }}>
                    <img src={p.img} alt={p.title} style={{ width:"100%", height:"160px", objectFit:"cover", display:"block" }}/>
                    <div style={{ position:"absolute", top:"8px", left:"8px", background:DARK, color:GOLD, fontSize:"9px", fontFamily:"sans-serif", fontWeight:"800", padding:"3px 8px", letterSpacing:"1px" }}>{p.cat.toUpperCase()}</div>
                  </div>
                  <div style={{ padding:"12px" }}>
                    <div style={{ fontSize:"14px", color:DARK, marginBottom:"4px" }}>{p.title}</div>
                    <div style={{ fontSize:"13px", color:GOLD, fontFamily:"sans-serif", fontWeight:"700" }}>${p.price}</div>
                    <button onClick={e=>{e.stopPropagation();setView("orders");setShowForm(true);}} style={{ ...btnGold, marginTop:"8px", width:"100%", padding:"7px", fontSize:"11px" }}>+ Dalabso</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ VIP DESIGNS ══ */}
        {view==="vip" && (
          <div>
            {/* VIP Hero */}
            <div style={{ background:`linear-gradient(135deg,${DARK},#3D2800)`, padding:"24px", marginBottom:"16px", textAlign:"center", border:`1px solid ${GOLD}` }}>
              <div style={{ color:GOLD, fontSize:"9px", letterSpacing:"4px", fontFamily:"sans-serif", marginBottom:"6px" }}>EXCLUSIVE COLLECTION</div>
              <div style={{ color:"#F9F5EE", fontSize:"24px", marginBottom:"6px" }}>💎 Nashqadaha VIP</div>
              <div style={{ color:"#9CA3AF", fontSize:"12px", fontFamily:"sans-serif" }}>Noocyada ugu qiimaha badan — xariir, dahab, fab Italy</div>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:"10px" }}>
              {VIP_DESIGNS.map(d=>(
                <div key={d.id} style={{ background:"#fff", border:`2px solid ${GOLD}`, overflow:"hidden" }}>
                  <div style={{ position:"relative" }}>
                    <img src={d.img} alt={d.name} style={{ width:"100%", height:"170px", objectFit:"cover", display:"block" }} onClick={()=>setLightbox(d.img)}/>
                    <div style={{ position:"absolute", top:"8px", right:"8px", background:d.tag==="VIP"?`linear-gradient(135deg,${GOLD},#E8C96A)`:d.tag==="CUSUB"?"#7C3AED":"#EF4444", color:d.tag==="VIP"?DARK:"#fff", fontSize:"9px", fontFamily:"sans-serif", fontWeight:"800", padding:"3px 8px", letterSpacing:"2px" }}>{d.tag}</div>
                  </div>
                  <div style={{ padding:"12px", background:`linear-gradient(180deg,#fff,#FFFBF0)` }}>
                    <div style={{ fontSize:"15px", color:DARK, marginBottom:"3px" }}>{d.name}</div>
                    <div style={{ fontSize:"11px", color:"#9CA3AF", fontFamily:"sans-serif", marginBottom:"8px" }}>{d.desc}</div>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                      <div style={{ fontSize:"18px", color:GOLD, fontFamily:"sans-serif", fontWeight:"800" }}>${d.price}</div>
                      <button onClick={()=>{setView("orders");setShowForm(true);setForm(f=>({...f,style:d.name.split(" ")[1]||"Custom",price:d.price}));}} style={{ ...btnGold, padding:"7px 14px", fontSize:"11px" }}>Dalabso</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ TRAINING ══ */}
        {view==="training" && (
          <div>
            <div style={{ background:`linear-gradient(135deg,${DARK},#1A2A08)`, padding:"24px", marginBottom:"16px", border:`1px solid ${GOLD}` }}>
              <div style={{ color:GOLD, fontSize:"9px", letterSpacing:"4px", fontFamily:"sans-serif", marginBottom:"6px" }}>HABANE TAILOR ACADEMY</div>
              <div style={{ color:"#F9F5EE", fontSize:"22px", marginBottom:"6px" }}>🎓 Barashada Tolmaha</div>
              <div style={{ color:"#9CA3AF", fontSize:"12px", fontFamily:"sans-serif" }}>Tarzannimada xirfadda leh baranayso — online iyo offline</div>
            </div>

            {/* Course card */}
            <div style={{ background:"#fff", border:`2px solid ${GOLD}`, padding:"20px", marginBottom:"14px", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:0, right:0, background:`linear-gradient(135deg,${GOLD},#E8C96A)`, color:DARK, fontSize:"9px", fontFamily:"sans-serif", fontWeight:"800", padding:"5px 14px", letterSpacing:"2px" }}>WAXBARASHO</div>
              <div style={{ fontSize:"18px", color:DARK, marginBottom:"8px" }}>📐 Kooraska Tolmaha</div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"10px", marginBottom:"14px" }}>
                {[
                  ["💰","Qiimaha","$20 / bisho"],
                  ["⏱","Waqtiga","30 daqiiqo maalin kasta"],
                  ["📅","Maalmaha","Khamiista & Jimcaha"],
                  ["🎯","Heerka","Bilow ilaa dhexe"],
                ].map(([e,l,v])=>(
                  <div key={l} style={{ background:CREAM, border:`1px solid ${BORDER}`, padding:"12px", display:"flex", gap:"10px", alignItems:"center" }}>
                    <span style={{ fontSize:"20px" }}>{e}</span>
                    <div>
                      <div style={{ fontSize:"10px", color:"#9CA3AF", fontFamily:"sans-serif" }}>{l}</div>
                      <div style={{ fontSize:"13px", color:DARK, fontWeight:"600" }}>{v}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD, marginBottom:"10px" }}>WAXA LAGU BARANAYO</div>
              {["✂ Qaabka iyo miisaanka (cabbirka)", "🪡 Noocyada xarigga iyo dunta", "👗 Dirac, Baati, Abaya tolista", "📐 Qaab-dhismeedka nashqadaha", "🎨 Midabada iyo decorations", "💼 Ganacsiga tarzanka — macaamiil soo jiidashada"].map((item,i)=>(
                <div key={i} style={{ display:"flex", alignItems:"center", gap:"10px", padding:"8px 0", borderBottom:`1px solid ${BORDER}`, fontSize:"13px", color:DARK, fontFamily:"sans-serif" }}>
                  <span style={{ color:GOLD }}>◆</span> {item}
                </div>
              ))}

              <div style={{ marginTop:"16px", padding:"14px", background:`linear-gradient(135deg,rgba(201,168,76,0.1),rgba(201,168,76,0.05))`, border:`1px solid rgba(201,168,76,0.3)` }}>
                <div style={{ fontSize:"11px", fontFamily:"sans-serif", color:"#9CA3AF", marginBottom:"4px" }}>JADWALKA XIGA</div>
                <div style={{ fontSize:"13px", color:DARK, fontFamily:"sans-serif" }}>📅 Khamiista, May 8 — 4:00 PM – 4:30 PM</div>
                <div style={{ fontSize:"13px", color:DARK, fontFamily:"sans-serif" }}>📅 Jimcaha, May 9 — 4:00 PM – 4:30 PM</div>
              </div>

              <div style={{ marginTop:"14px", background:"#FFF7ED", border:"1px solid #FCA5A5", padding:"10px 14px", fontSize:"12px", fontFamily:"sans-serif", color:"#C2410C" }}>
                ⚠ Fasaxyada: Khamiista iyo Jimcaha fasax — Casho iyo Ciid
              </div>

              <button style={{ ...btnGold, width:"100%", padding:"12px", fontSize:"14px", marginTop:"14px", letterSpacing:"2px" }}>
                📲 Isdiiwaangeli — $20/bisho
              </button>
            </div>

            {/* Testimonials */}
            <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD, marginBottom:"12px" }}>ARDAYDA HORE</div>
            {[
              { name:"Hodan M.", text:"6 bilood kadib waxaan leeyahay shaqadayda tolmaha!", stars:5 },
              { name:"Ilhan A.", text:"Macalinka aad ayuu u sabriyaa, si fiican ayuu u sharxaa.", stars:5 },
              { name:"Nasro K.", text:"$20 bishii aad bay u jaban tahay — wax badan baad barataa!", stars:5 },
            ].map((t,i)=>(
              <div key={i} style={{ background:"#fff", border:`1px solid ${BORDER}`, padding:"14px", marginBottom:"8px" }}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"6px" }}>
                  <span style={{ fontSize:"14px", color:DARK }}>{t.name}</span>
                  <span style={{ color:GOLD }}>{"⭐".repeat(t.stars)}</span>
                </div>
                <div style={{ fontSize:"13px", color:"#78716C", fontFamily:"sans-serif" }}>"{t.text}"</div>
              </div>
            ))}
          </div>
        )}

        {/* ══ STATS ══ */}
        {view==="stats" && (
          <div>
            <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD, marginBottom:"14px" }}>📊 WARBIXINTA MAALIYADDA</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"8px", marginBottom:"18px" }}>
              {[
                ["💰 La Helay",`$${totalRev}`,"#F0FDF4","#15803D"],
                ["⏳ Sugaya",`$${totalOwed}`,"#FFF7ED","#C2410C"],
                ["📋 Dalabyo",orders.length,"#EFF6FF","#1D4ED8"],
                ["✅ Diyaar",orders.filter(o=>o.status==="Ready").length,"#F0FDF4","#15803D"],
              ].map(([l,v,bg,col])=>(
                <div key={l} style={{ background:bg, border:`1px solid ${col}33`, padding:"18px", textAlign:"center" }}>
                  <div style={{ fontSize:"10px", fontFamily:"sans-serif", color:col, marginBottom:"4px" }}>{l}</div>
                  <div style={{ fontSize:"26px", color:col }}>{v}</div>
                </div>
              ))}
            </div>

            <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD, marginBottom:"10px" }}>🏆 MACAAMIISHA UGUGSAN</div>
            {[...Object.values(clientMap)].sort((a,b)=>b.orders.length-a.orders.length).slice(0,5).map((c,i)=>{
              const badge=getBadge(c.orders.length);
              const spent=c.orders.reduce((s,o)=>s+(o.paid?o.price:0),0);
              return (
                <div key={c.name} style={{ background:"#fff", border:`1px solid ${BORDER}`, padding:"12px 16px", marginBottom:"7px", display:"flex", alignItems:"center", gap:"12px", boxShadow:i===0?`0 0 0 2px ${GOLD}`:"none" }}>
                  <div style={{ width:"28px", height:"28px", background:i===0?`linear-gradient(135deg,${GOLD},#E8C96A)`:CREAM, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"12px", color:i===0?DARK:GOLD, fontFamily:"sans-serif", fontWeight:"800" }}>
                    {i===0?"🏆":i+1}
                  </div>
                  <div style={{ flex:1 }}>
                    <span style={{ color:DARK, fontSize:"14px" }}>{c.name}</span>
                    {badge&&<span style={{ marginLeft:"6px", fontSize:"13px" }}>{badge.emoji}</span>}
                  </div>
                  <div style={{ fontFamily:"sans-serif", fontSize:"12px", textAlign:"right" }}>
                    <div style={{ color:DARK }}>{c.orders.length} dalabyo</div>
                    <div style={{ color:"#15803D", fontWeight:"700" }}>${spent}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* PAYMENT MODAL */}
      {payModal && (()=>{
        const po = orders.find(o=>o.id===payModal);
        if (!po) return null;
        const METHODS = [
          { id:"zaad",       name:"Zaad",        logo:"🟡", color:"#F59E0B", bg:"#FFFBEB", num:"252611xxxxxx", desc:"Hormuud Telecom" },
          { id:"edahab",     name:"eDahab",      logo:"🔴", color:"#DC2626", bg:"#FEF2F2", num:"252615xxxxxx", desc:"Somtel" },
          { id:"mastercard", name:"Mastercard",  logo:"💳", color:"#1D4ED8", bg:"#EFF6FF", num:"**** **** **** xxxx", desc:"International Card" },
        ];
        return (
          <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.75)", zIndex:999, display:"flex", alignItems:"flex-end", justifyContent:"center" }}>
            <div style={{ background:"#fff", width:"100%", maxWidth:"480px", borderRadius:"12px 12px 0 0", padding:"24px", maxHeight:"90vh", overflowY:"auto" }}>
              {/* handle bar */}
              <div style={{ width:"40px", height:"4px", background:"#E5E0D8", borderRadius:"2px", margin:"0 auto 18px" }}/>
              <div style={{ textAlign:"center", marginBottom:"6px" }}>
                <div style={{ fontSize:"10px", fontFamily:"sans-serif", letterSpacing:"3px", color:GOLD, marginBottom:"4px" }}>LACAG BIXINTA</div>
                <div style={{ fontSize:"28px", color:DARK, fontWeight:"400" }}>${po.price}</div>
                <div style={{ fontSize:"12px", color:"#9CA3AF", fontFamily:"sans-serif" }}>{po.name} · {po.style}</div>
              </div>

              {po.paid ? (
                <div style={{ margin:"16px 0", padding:"14px", background:"#F0FDF4", border:"1px solid #4ADE80", textAlign:"center" }}>
                  <div style={{ fontSize:"24px", marginBottom:"4px" }}>✅</div>
                  <div style={{ fontSize:"14px", color:"#15803D", fontFamily:"sans-serif", fontWeight:"700" }}>Lacagta waa la bixiyay</div>
                  <div style={{ fontSize:"12px", color:"#9CA3AF", fontFamily:"sans-serif", marginTop:"2px" }}>Hab: {po.payMethod}</div>
                  <button onClick={()=>{setOrders(orders.map(o=>o.id===payModal?{...o,paid:false,payMethod:""}:o));}} style={{ marginTop:"10px", background:"#FEF2F2", color:"#DC2626", border:"1px solid #FCA5A5", padding:"6px 16px", cursor:"pointer", fontSize:"12px", fontFamily:"sans-serif", fontWeight:"700" }}>
                    ↩ Dib u celi
                  </button>
                </div>
              ) : (
                <div style={{ margin:"16px 0" }}>
                  <div style={{ fontSize:"11px", fontFamily:"sans-serif", letterSpacing:"2px", color:GOLD, marginBottom:"12px", textAlign:"center" }}>HAB U DOORO</div>
                  {METHODS.map(m=>(
                    <button key={m.id} onClick={()=>{ setOrders(orders.map(o=>o.id===payModal?{...o,paid:true,payMethod:m.name}:o)); setPayModal(null); }}
                      style={{ width:"100%", display:"flex", alignItems:"center", gap:"14px", padding:"14px 16px", background:m.bg, border:`2px solid ${m.color}22`, marginBottom:"10px", cursor:"pointer", textAlign:"left", transition:"all 0.15s", boxSizing:"border-box" }}>
                      <span style={{ fontSize:"28px" }}>{m.logo}</span>
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:"16px", color:DARK, fontWeight:"700", fontFamily:"sans-serif" }}>{m.name}</div>
                        <div style={{ fontSize:"11px", color:"#9CA3AF", fontFamily:"sans-serif" }}>{m.desc}</div>
                        <div style={{ fontSize:"11px", color:m.color, fontFamily:"sans-serif", marginTop:"2px", fontWeight:"600" }}>{m.num}</div>
                      </div>
                      <div style={{ color:m.color, fontSize:"20px" }}>→</div>
                    </button>
                  ))}
                </div>
              )}

              <button onClick={()=>setPayModal(null)} style={{ width:"100%", padding:"12px", background:DARK, color:CREAM, border:"none", cursor:"pointer", fontSize:"13px", fontFamily:"sans-serif", fontWeight:"600", letterSpacing:"1px", boxSizing:"border-box" }}>
                Xir
              </button>
            </div>
          </div>
        );
      })()}

      {/* LIGHTBOX */}
      {lightbox&&(
        <div onClick={()=>setLightbox(null)} style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.94)", zIndex:1000, display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer" }}>
          <img src={lightbox} alt="" style={{ maxWidth:"93vw", maxHeight:"93vh", objectFit:"contain" }}/>
          <button onClick={()=>setLightbox(null)} style={{ position:"absolute", top:"16px", right:"16px", background:"none", border:"none", color:"#fff", fontSize:"30px", cursor:"pointer" }}>×</button>
        </div>
      )}

      <div style={{ textAlign:"center", padding:"12px", fontFamily:"sans-serif", fontSize:"10px", color:"#C4BAB0", letterSpacing:"2px", borderTop:`1px solid ${BORDER}` }}>
        ✂ HABANE TAILOR · BOORAMA · {orders.length} DALABYO
      </div>
    </div>
  );
}
