# ✂ Habane Tailor — Boorama

App-ka maamulidda tarzanka — dalabyo, macaamiil, lacag-bixinta, barashada.

## Sida loo shido locally

```bash
npm install
npm run dev
```

## Sida Vercel loogu soo raro

1. GitHub-ka ku soo rar
2. vercel.com tag
3. "New Project" → GitHub repo dooro
4. Deploy riix — dhammaatay!
